# Yo create website

Plain HTML, no build step. Upload the whole folder to a GitHub repository.

## Put it on GitHub Pages
1. Create a repository and upload everything in this folder (keep the `assets` folder and `index.html` at the top level).
2. Settings, then Pages. Branch `main`, folder `/ (root)`, Save.
3. Your site appears at `https://YOURNAME.github.io/REPO/`.

## Turn on login (Firebase, free tier)
1. Go to console.firebase.google.com and create a project.
2. Build, then Authentication, Get started, enable **Email/Password**.
3. Authentication, Settings, Authorized domains: add `YOURNAME.github.io`.
4. Build, then Firestore Database, create it, then paste these rules:
```
rules_version = '2';
service cloud.firestore { match /databases/{db}/documents {
  match /members/{uid} { allow read, write: if request.auth != null && request.auth.uid == uid; }
} }
```
5. Project settings, Your apps, add a Web app, copy `apiKey`, `authDomain`, `projectId`, `appId` into `config.js`.

## Turn on PayPal subscriptions
1. Use a PayPal **Business** account owned by an adult.
2. Developer dashboard: create an app and copy the **Client ID** into `config.js`.
3. Create two subscription plans (£12 monthly Kids box, £25 monthly Teen box) and copy each Plan ID into `config.js`.
4. Test in PayPal sandbox first.
5. Only set `paymentsOpen: true` once the toys have passed their safety checks and the adults are ready.

## Good to know
- Until `paymentsOpen` is true, signed-in people can join the waitlist (saved on their account).
- Orders saved by the website can be faked by a user with browser tools. Treat the **PayPal dashboard** as the real record of who paid, and check it before posting a box.
- Add a privacy notice before collecting real emails (UK GDPR). Accounts are for adults (18+).
- Change contact details and links in `config.js`. Colours and fonts are at the top of `site.css`.
