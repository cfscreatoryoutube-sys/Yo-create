(function () {
  var Y = window.YO, p = location.pathname.split('/').pop() || 'index.html';
  var nav = [['index.html', 'Home'], ['boxes.html', 'Boxes'], ['prototype.html', 'Prototype'], ['contact.html', 'Contact']];
  var links = nav.map(function (n) {
    return '<a href="' + n[0] + '"' + (p === n[0] ? ' aria-current="page"' : '') + '>' + n[1] + '</a>';
  }).join('');
  document.getElementById('site-header').innerHTML =
    '<header class="bar"><div class="wrap bar-in"><a class="brand" href="index.html"><img src="assets/logo.png" alt="Yo create, home" width="48" height="48"></a>' +
    '<nav aria-label="Main">' + links + '<a class="acct" id="acct" href="account.html"' + (p === 'account.html' ? ' aria-current="page"' : '') + '>Sign in</a></nav></div></header>';
  document.getElementById('site-footer').innerHTML =
    '<footer class="foot"><div class="wrap foot-in"><p>© 2026 Yo create. Made in the UK.</p>' +
    '<p><a href="mailto:' + Y.email + '">' + Y.email + '</a></p>' +
    '<p><a href="' + Y.reddit + '" target="_blank" rel="noopener">Reddit</a> <a href="' + Y.youtube + '" target="_blank" rel="noopener">YouTube</a></p></div></footer>';
})();
