import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js";
import { getAuth, onAuthStateChanged, signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut, sendPasswordResetEmail } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";
import { getFirestore, doc, getDoc, setDoc, arrayUnion } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";

const cfg = window.YO.firebase, on = !!cfg.apiKey;
const yo = window.yo = { enabled: on, user: null, ready: false, _cbs: [],
  onUser(cb) { this._cbs.push(cb); if (this.ready) cb(this.user); } };

function emit() {
  yo.ready = true;
  yo._cbs.forEach(cb => cb(yo.user));
  const a = document.getElementById('acct');
  if (a) a.textContent = yo.user ? 'My boxes' : 'Sign in';
}

if (!on) { emit(); } else {
  const app = initializeApp(cfg), auth = getAuth(app), db = getFirestore(app);
  yo.signIn = (e, p) => signInWithEmailAndPassword(auth, e, p);
  yo.signUp = (e, p) => createUserWithEmailAndPassword(auth, e, p);
  yo.signOut = () => signOut(auth);
  yo.reset = e => sendPasswordResetEmail(auth, e);
  yo.loadBoxes = async () => {
    const s = await getDoc(doc(db, 'members', yo.user.uid));
    return s.exists() ? (s.data().boxes || []) : [];
  };
  yo.saveBox = (box, ref) => setDoc(doc(db, 'members', yo.user.uid),
    { email: yo.user.email, boxes: arrayUnion({ box, ref, at: new Date().toISOString() }) }, { merge: true });
  onAuthStateChanged(auth, u => { yo.user = u; emit(); });
}
