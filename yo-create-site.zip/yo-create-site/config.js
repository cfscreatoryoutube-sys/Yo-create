// Edit this file, then re-upload it. See README.md for where each value comes from.
window.YO = {
  // Keep false until the toys have passed their safety checks and the adults are ready to take money.
  paymentsOpen: false,
  firebase: { apiKey: "", authDomain: "", projectId: "", appId: "" },
  paypal: { clientId: "", plans: { kids: "", teen: "" } }, // plans = PayPal subscription plan IDs
  email: "yo.create.official@gmail.com",
  reddit: "https://www.reddit.com/r/Yocreate/",
  redditUser: "https://www.reddit.com/user/Yo-create/",
  youtube: "https://www.youtube.com/@Yo-create"
};
